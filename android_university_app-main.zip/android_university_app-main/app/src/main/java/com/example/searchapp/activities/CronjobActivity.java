package com.example.searchapp.activities;
//We can optimise foreground service by using this activity
import androidx.appcompat.app.AppCompatActivity;


public class CronjobActivity extends AppCompatActivity {

}
